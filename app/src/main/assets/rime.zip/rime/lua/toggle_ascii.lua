
local function processor(key, env)
    -- 检测是否按下了 Control + Space
    if key:repr() == "Control+space" then
        local context = env.engine.context
        
        -- 1. 核心修复：如果是正在输入状态，直接调用底层内存清理
        if context:is_composing() then
            context:clear()
        end
        
        -- 2. 翻转切换中英文状态开关 (ascii_mode)
        local ascii_mode = context:get_option("ascii_mode")
        context:set_option("ascii_mode", not ascii_mode)
        
        -- 3. 返回 0 (kAccepted)，表示该按键已被 Lua 完美消费并销毁，不传给 key_binder
        return 0
    end
    
    -- 如果不是 Ctrl+Space，返回 2 (kNoop)，交还给 Rime 后续组件正常打字
    return 2
end
